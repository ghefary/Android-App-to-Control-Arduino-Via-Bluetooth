package org.ghifary.robot;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DB extends SQLiteOpenHelper {

    public static String db_name = "robot_db";
    public static String table_name = "actions";
    public static String col1 = "id";
    public static String col2 = "robot_name";
    public static String col3 = "movement";

    public DB(Context context){

        super(context,db_name,null,1);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("CREATE TABLE "+table_name+"("+col1+" INTEGER PRIMARY KEY AUTOINCREMENT , "+col2+" TEXT , "+col3+" TEXT )");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+table_name);

    }


    public  String insert_data(String name, String movement){
        try {
            ContentValues cont_obj = new ContentValues();
            cont_obj.put(col2, name);
            cont_obj.put(col3, movement);

            //apply these content valuse obj on the db
            SQLiteDatabase obj_db = this.getWritableDatabase();

            obj_db.insert(table_name, null, cont_obj);
            return "data inserted successfully";
        }
        catch (Exception e ){

            return "## error ## ==> "+e.getMessage();

        }

    }


    public Cursor get_all_data(){

        SQLiteDatabase db = this.getReadableDatabase();
        //id ==> select specific row
        Cursor c = db.rawQuery("SELECT * FROM "+table_name+" WHERE id = 10",null);
        return c; //return pointer(cusrsor)

    }



}
