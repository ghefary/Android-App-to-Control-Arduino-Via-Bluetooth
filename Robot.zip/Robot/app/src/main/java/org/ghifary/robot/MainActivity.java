package org.ghifary.robot;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText user_name;
    EditText password;
    DB db_obj;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        user_name = findViewById(R.id.user_name);
        password = findViewById(R.id.password);

    }

    public void authenication(View v) {
        String user = user_name.getText().toString();
        String pass = password.getText().toString();

/*
        db_obj = new DB(this);
        Cursor c = db_obj.get_all_data();
        //  Toast.makeText(this, String.valueOf(c.getCount()), Toast.LENGTH_LONG).show();
        String admin_name = "";
        String pass_word = "";
        while (c.moveToNext()) {//move to next ==> check existence of valuse &  1st line +  next lines
            admin_name = c.getString(1);
            pass_word = c.getString(2);

*/
            if (user.equals("ahmed") && pass.equals("0100200300")) {
                Intent intent_obj = new Intent(this, c_panel.class);
                Toast.makeText(this, " Successfully  ", Toast.LENGTH_LONG).show();
                intent_obj.putExtra("welcome_msg", user);
                startActivity(intent_obj);
            } else {
                Toast.makeText(this, "failed please try again ", Toast.LENGTH_LONG).show();





        }
    }
}