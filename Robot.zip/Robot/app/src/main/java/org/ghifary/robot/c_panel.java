package org.ghifary.robot;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;



public class c_panel extends AppCompatActivity {
    TextView wel_msg;
    Button back_button;
    DB db_obj;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_c_panel);
        wel_msg = findViewById(R.id.welcome_msg);
        String welcome = getIntent().getStringExtra("welcome_msg");
        wel_msg.setText("Welcome Admin "+ welcome);
        Toast.makeText(this,"Hello "+welcome,Toast.LENGTH_LONG).show();
        back_button = findViewById(R.id.back_button);



        back_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent_obj = new Intent(c_panel.this,MainActivity.class);
                startActivity(intent_obj);

            }
        });

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

    }

    /*
    public void back_to_previous_activity(View v){

        Intent intent_obj = new Intent(this,MainActivity.class);
        startActivity(intent_obj);

    }
    */

    public void insert_to_DB(View v){
        DB db_obj = new DB(this);
        String user_name = "mido";
        String password= "ghifary";

        String result = db_obj.insert_data(user_name,password);
        Toast.makeText(this,result,Toast.LENGTH_LONG).show();


    }

    public void test(View v){

        db_obj = new DB(this);
        Cursor c =db_obj.get_all_data();
        // Log.i("COUNT", String.valueOf(c.getCount())) ;//count : num of rows u have slelected by cursor from db
        Toast.makeText(this, String.valueOf(c.getCount()), Toast.LENGTH_LONG).show();
        while (c.moveToNext()) {//move to next ==> check existence of valuse &  1st line +  next lines
            String xxx = c.getString(1);
            // wel_msg.setText(xxx);
        }
    }


}
